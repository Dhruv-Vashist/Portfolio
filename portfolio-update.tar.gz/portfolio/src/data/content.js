// ─────────────────────────────────────────────────────────────
//  Your personal details live here. Replace the sample text
//  (name, tagline, about, email, links) with your own.
// ─────────────────────────────────────────────────────────────

export const profile = {
  name: 'Elaine Paula Hernandez',
  greeting: 'hi! i’m',
  role: 'I’M A DESIGNER',
  quote: '“Meaningful design starts with intention”',
  iconLetter: 'h',
  photo: '/profile.jpg',
  email: 'hello@example.com',
  location: 'Manila, Philippines',
  resume: '/resume.pdf', // drop your PDF into /public/resume.pdf
  about:
    'I design clear, friendly interfaces and brand systems. I care about the small decisions — spacing, wording, motion — that make a product feel considered.',
};

/*
  Social links shown in the taskbar and on the Connect page — in this order.
  `id` picks the icon. Available: linkedin, github, behance, dribbble, youtube, reddit,
  discord, twitter, codeforces, leetcode, instagram.  Any other id shows a generic link icon.
  Add, remove or reorder lines freely (the taskbar fits about 6 icons on a phone).
*/
// Your links. The taskbar and Connect page show these in order.
//  • id picks the icon: linkedin, github, youtube, reddit, discord, twitter (or x),
//    codeforces, instagram, behance, dribbble, website, email.
//  • Any other id works too — add  color: '#hex'  and  letter: 'L'  for a custom badge.
//  • Delete a line to remove an icon; add a line to add one.
export const socials = [
  { id: 'linkedin', label: 'LinkedIn', url: 'https://www.linkedin.com/in/your-handle' },
  { id: 'github', label: 'GitHub', url: 'https://github.com/your-handle' },
  { id: 'youtube', label: 'YouTube', url: 'https://www.youtube.com/@your-handle' },
  { id: 'reddit', label: 'Reddit', url: 'https://www.reddit.com/user/your-handle' },
  { id: 'discord', label: 'Discord', url: 'https://discord.com/users/YOUR_NUMERIC_ID' },
  { id: 'twitter', label: 'X / Twitter', url: 'https://x.com/your-handle' },
  { id: 'codeforces', label: 'Codeforces', url: 'https://codeforces.com/profile/your-handle' },
];

// ─────────────────────────────────────────────────────────────
//  TECHNICAL SKILLS — shown in the "skills" folder.
//  Edit the lines below; each group becomes one row.
// ─────────────────────────────────────────────────────────────
export const skills = [
  { group: 'Programming Languages', items: ['C++', 'C', 'Python'] },
  { group: 'Graphics APIs', items: ['Vulkan', 'Direct3D 12 (DX12)', 'OpenGL'] },
  {
    group: 'Shader Programming',
    items: ['HLSL', 'GLSL', 'Vertex and fragment shaders', 'Compute shaders'],
  },
  {
    group: 'Computer Graphics',
    items: [
      'Real-Time Rendering',
      'Rasterization',
      'Rendering Pipelines',
      'PBR',
      'Lighting and Shading',
      'Shadow Mapping',
      'Texture Mapping',
      'Post-Processing',
    ],
  },
  {
    group: 'Mathematics',
    items: [
      'Linear Algebra',
      '3D Transformations',
      'Coordinate Systems',
      'Projection Matrices',
      '3D Geometry',
      'Calculus',
    ],
  },
  {
    group: 'Systems Programming',
    items: ['Data Structures and Algorithms', 'Memory Management', 'Multithreading', 'CPU/GPU Architecture'],
  },
  {
    group: 'Tools and Build Systems',
    items: ['Visual Studio', 'CMake', 'Git', 'GitHub', 'RenderDoc', 'Vulkan SDK', 'GPU Profiling Tools'],
  },
  { group: 'Operating Systems', items: ['Windows', 'Linux'] },
];

// ─────────────────────────────────────────────────────────────
//  EXPERIENCE, PROJECTS, ACHIEVEMENTS
//  You do NOT need to edit code to add these. Log in as owner
//  (Blog page → "Owner login"), open the folder and click
//  "＋ Add …". They are saved online and appear for everyone.
//
//  The empty lists below are optional "built-in" entries that are
//  always shown (and can only be changed here in the code).
//  Format example for experience:
//   { role: 'Graphics Intern', company: 'Studio', location: 'Remote',
//     period: '2026 — Present', points: ['Did this', 'Did that'] }
// ─────────────────────────────────────────────────────────────
export const experience = [];
export const projects = [];
export const achievements = [];
